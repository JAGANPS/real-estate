# Real Estate Management System

Project Description:
In this project, I created a simple management of real estate. I made it using PHP and MySQL

## SETUP
The `realestate.sql` file contains the MySQL Schema and some sample data. Import the file in a new database
You only must to configure the `conexion.php` file. There is the DataBase configuration

The folder ./inmoadmin/ is used for CRUD 
User: admin
Pass: admin



## Requierments
PHP interpreter
MySQL DBE
You could use the XAMPP or WAMP software to simplify the installation and running


## Contact
For contact send an email to crismablanco@gmail.com

Best Regards
Cristian Blanco