<?php
$server='localhost';
$base='educ4r_pomares';
$usuario='educ4r_pomares';
$pass='fu68MOlivo';

$link = mysql_connect($server, $usuario, $pass);


?>